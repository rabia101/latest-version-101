-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2019 at 05:59 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bottique`
--

-- --------------------------------------------------------

--
-- Table structure for table `boutique_order`
--

CREATE TABLE `boutique_order` (
  `orderid` int(11) NOT NULL,
  `bo_id` int(11) DEFAULT NULL,
  `customerid` int(12) DEFAULT NULL,
  `amount` varchar(250) DEFAULT NULL,
  `date` varchar(345) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `boutique_order`
--

INSERT INTO `boutique_order` (`orderid`, `bo_id`, `customerid`, `amount`, `date`, `status`) VALUES
(1, 101, 123, '20', '5', '6');

-- --------------------------------------------------------

--
-- Table structure for table `boutique_post`
--

CREATE TABLE `boutique_post` (
  `id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `vendor_name` varchar(50) NOT NULL,
  `vendor_city` varchar(50) NOT NULL,
  `category_id` int(11) NOT NULL,
  `category_name` varchar(50) NOT NULL,
  `prd_name` varchar(100) NOT NULL,
  `prd_image` varchar(100) NOT NULL,
  `prd_qty` int(11) NOT NULL,
  `prd_price` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `prd_desc` text,
  `prd_quality` varchar(50) DEFAULT NULL,
  `vendor_contact` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `boutique_post`
--

INSERT INTO `boutique_post` (`id`, `vendor_id`, `vendor_name`, `vendor_city`, `category_id`, `category_name`, `prd_name`, `prd_image`, `prd_qty`, `prd_price`, `date`, `prd_desc`, `prd_quality`, `vendor_contact`) VALUES
(6, 1259, 'Musawer ALi', 'Bahawalpur', 7, '', 'Leather Shoes (Orignal)', '031-Shoes-to-wear-with-jeans.jpeg', 100, 2999, '2019-05-17 12:25:39', 'Upper Leather,\r\nRubber Sole,\r\nSIze:41 to 45', 'Upper Leather', '+923336513516'),
(7, 1259, 'Musawer ALi', 'Bahawalpur', 5, '', 'Blue Jeans', '13a5e9eee22ce15319cd14c9f28e582d.jpg', 200, 999, '2019-05-17 12:30:46', '4 seasons\r\ntwo colors\r\n32 to 45 waste', 'Fiber Cotton', '+923336513516'),
(13, 1259, 'Musawer ALi', 'Bahawalpur', 3, '', 'Ladies Stritching Cloth', 'maria-salman-collection.jpg', 200, 3999, '2019-05-17 13:08:38', '4 Season,Good Quality,\r\nAge 21 to 28', 'Maria Sulman Washing ware', '+92333651351'),
(14, 1259, 'Musawer ALi', 'Bahawalpur', 3, '', 'Ladies Stritching Cloth', 'classic-vol1-collection.jpg', 20, 2999, '2019-05-17 13:10:44', '4 Season', 'Washingware (Summer)', '+92333651351'),
(15, 1259, 'Musawer ALi', 'Bahawalpur', 5, '', 'Men Jeans', 'menscomingsoonpage-edit.jpg', 80, 1999, '2019-05-17 13:13:10', 'Orignal Dennim Branded', 'Dennim', '923336513516'),
(16, 1260, 'Ch Musawer', 'Bahawalpur', 8, '', 'Pary suites', 'clothing.jpg', 50, 9999, '2019-05-17 14:57:49', 'Party Suites Branded', 'Tom Tailor', '923336513516'),
(17, 1260, 'Ch Musawer', 'Bahawalpur', 9, '', 't-shirts', 'FI015-1920x1080-t-shirts-en.jpg', 1000, 399, '2019-05-17 14:59:18', 'Available All Colors\r\nGood Quality', 'Denim', '923336513516'),
(18, 1259, 'Musawer ALi', 'Bahawalpur', 10, '', 'Wedding dresses', 'indian-wedding-suits-for-men-1.jpg', 100, 7999, '2019-05-18 14:01:06', 'All types of available', 'Branded', '923336513516'),
(19, 1259, 'Musawer ALi', 'Bahawalpur', 11, '', '7 piece suite', 'Suit.png', 70, 5999, '2019-05-18 14:03:14', 'Suites for Men', 'L.Tailor', '923336513516'),
(20, 1260, 'Owner', 'Bahawalpur', 9, '', 'shirt', '3b7cb5c291bef9a5162dd7c41cc09267--originals-online-khaadi-lawn-.jpg', 1, 160, '2019-05-27 05:34:40', 'sdfgff', 'good', '92333000000'),
(21, 1260, 'Owner', 'Bahawalpur', 4, '', 'Trouser', 'za2.jpg', 2, 1050, '2019-05-28 15:11:04', 'fdgsafahGJ', 'good', '92333000000'),
(22, 1260, 'Owner', 'Bahawalpur', 12, '', 'Trouser', 'WhatsApp_Image_2019-02-01_at_3.27_.11_PM_.jpeg', 10, 1160, '2019-05-28 15:13:52', 'gwqhUH', 'good', '92333000000'),
(23, 1260, 'Owner', 'Bahawalpur', 4, '', 'dress', 'images (26).jpg', 1, 1880, '2019-06-01 05:05:26', 'hfhuewqhgeiq', 'good', '92333000000'),
(24, 1260, 'Owner', 'Bahawalpur', 4, '', 'dress', 'WhatsApp_Image_2019-01-28_at_9.31_.31_PM_.jpeg', 1, 1200, '2019-06-10 03:30:25', 'fytewgfu', 'good', '92333000000'),
(25, 1260, 'Owner', 'Bahawalpur', 4, '', 'dress', 'images (12).jpg', 1, 1300, '2019-06-10 03:31:12', 'jajqjk', 'good', '92333000000');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `user_cnic` varchar(50) NOT NULL,
  `user_contact` varchar(50) NOT NULL,
  `prd_name` varchar(50) NOT NULL,
  `vendor_city` varchar(50) NOT NULL,
  `prd_price` int(11) NOT NULL,
  `prd_quality` varchar(50) NOT NULL,
  `prd_qty` int(11) NOT NULL,
  `prd_desc` text NOT NULL,
  `vendor_contact` varchar(50) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `total` int(11) NOT NULL,
  `prd_image` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `vendor_id`, `customer_name`, `address`, `user_cnic`, `user_contact`, `prd_name`, `vendor_city`, `prd_price`, `prd_quality`, `prd_qty`, `prd_desc`, `vendor_contact`, `date`, `total`, `prd_image`) VALUES
(5, 1253, 1260, 'rabia ', '\"189/f\"', '31202-70111746-4', '03009687669', 't-shirts', 'Bahawalpur', 399, 'Denim', 6, 'Available All Colors\r\nGood Quality\"', '923336513516', '2019-05-18 17:23:25', 2394, 'FI015-1920x1080-t-shirts-en.jpg'),
(6, 1261, 1259, 'Ali Raza', '\"Trust Colony,Bahawalpur\"', '3120269441941', '+92300123456', 'Blue Jeans', 'Bahawalpur', 999, 'Fiber Cotton', 2, '4 seasons\r\ntwo colors\r\n32 to 45 waste\"', '+923336513516', '2019-05-18 18:52:28', 1998, '13a5e9eee22ce15319cd14c9f28e582d.jpg'),
(7, 1261, 1260, 'Ali Raza', '\"Trust Colony,Bahawalpur\"', '3120269441941', '+92300123456', 't-shirts', 'Bahawalpur', 399, 'Denim', 1, 'Available All Colors\r\nGood Quality\"', '923336513516', '2019-05-18 18:52:46', 399, 'FI015-1920x1080-t-shirts-en.jpg'),
(8, 1261, 1259, 'Ali Raza', '\"Trust Colony,Bahawalpur\"', '3120269441941', '+92300123456', 'Leather Shoes (Orignal)', 'Bahawalpur', 2999, 'Upper Leather', 4, 'Upper Leather,\r\nRubber Sole,\r\nSIze:41 to 45\"', '+923336513516', '2019-05-18 18:53:17', 11996, '031-Shoes-to-wear-with-jeans.jpeg'),
(9, 1253, 1259, 'rabia ', '\"189/f\"', '31202-70111746-4', '03009687669', 'Blue Jeans', 'Bahawalpur', 999, 'Fiber Cotton', 1, '4 seasons\r\ntwo colors\r\n32 to 45 waste\"', '+923336513516', '2019-05-25 10:59:43', 999, '13a5e9eee22ce15319cd14c9f28e582d.jpg'),
(10, 1261, 1259, 'User', '\"\"', '3120269441941', '+920000000', 'Wedding dresses', 'Bahawalpur', 7999, 'Branded', 1, 'All types of available\"', '923336513516', '2019-05-27 10:38:49', 7999, 'indian-wedding-suits-for-men-1.jpg'),
(11, 1261, 1259, 'User', '\"\"', '3120269441941', '+920000000', 'Ladies Stritching Cloth', 'Bahawalpur', 3999, 'Maria Sulman Washing ware', 2, '4 Season,Good Quality,\r\nAge 21 to 28\"', '+92333651351', '2019-05-27 10:42:01', 7998, 'maria-salman-collection.jpg'),
(12, 1261, 1259, 'User', '\"\"', '3120269441941', '+920000000', 'Blue Jeans', 'Bahawalpur', 999, 'Fiber Cotton', 4, '4 seasons\r\ntwo colors\r\n32 to 45 waste\"', '+923336513516', '2019-05-28 19:54:14', 3996, '13a5e9eee22ce15319cd14c9f28e582d.jpg'),
(13, 1253, 1259, 'customer', '\"189/f\"', '31202-70111746-4', '03009687669', 'Leather Shoes (Orignal)', 'Bahawalpur', 2999, 'Upper Leather', 3, 'Upper Leather,\r\nRubber Sole,\r\nSIze:41 to 45\"', '+923336513516', '2019-05-28 20:01:46', 8997, '031-Shoes-to-wear-with-jeans.jpeg'),
(14, 1253, 1259, 'customer', '\"189/f\"', '31202-70111746-4', '03009687669', 'Ladies Stritching Cloth', 'Bahawalpur', 2999, 'Washingware (Summer)', 1, '4 Season\"', '+92333651351', '2019-05-28 20:03:01', 2999, 'classic-vol1-collection.jpg'),
(15, 1263, 1260, 'ammar', '\"3E\"', '1', '03009687669', 'shirt', 'Bahawalpur', 160, 'good', 20, 'sdfgff\"', '92333000000', '2019-05-28 20:34:05', 3200, '3b7cb5c291bef9a5162dd7c41cc09267--originals-online'),
(16, 1263, 1260, 'ammar', '\"3E\"', '1', '03009687669', 'Trouser', 'Bahawalpur', 1160, 'good', 1, 'gwqhUH\"', '92333000000', '2019-05-28 20:34:42', 1160, 'WhatsApp_Image_2019-02-01_at_3.27_.11_PM_.jpeg'),
(17, 1262, 1259, 'rabia', '\"189f\"', '-1', '03009687669', 'Men Jeans', 'Bahawalpur', 1999, 'Dennim', 1, 'Orignal Dennim Branded\"', '923336513516', '2019-06-01 10:01:31', 1999, 'menscomingsoonpage-edit.jpg'),
(18, 1253, 1259, 'customer', '\"189/f\"', '31202-70111746-4', '03009687669', 'Ladies Stritching Cloth', 'Bahawalpur', 3999, 'Maria Sulman Washing ware', 4, '4 Season,Good Quality,\r\nAge 21 to 28\"', '+92333651351', '2019-06-07 10:16:47', 15996, 'maria-salman-collection.jpg'),
(19, 1262, 1259, 'rabia', '\"189f\"', '-1', '03009687669', 'Ladies Stritching Cloth', 'Bahawalpur', 2999, 'Washingware (Summer)', 120, '4 Season\"', '+92333651351', '2019-06-07 10:20:40', 359880, 'classic-vol1-collection.jpg'),
(20, 1262, 1259, 'rabia', '\"189f\"', '-1', '03009687669', 'Ladies Stritching Cloth', 'Bahawalpur', 2999, 'Washingware (Summer)', 120, '4 Season\"', '+92333651351', '2019-06-07 10:20:40', 359880, 'classic-vol1-collection.jpg'),
(21, 1262, 1260, 'rabia', '\"189f\"', '-1', '03009687669', 'dress', 'Bahawalpur', 1880, 'good', 5, 'hfhuewqhgeiq\"', '92333000000', '2019-06-07 10:21:43', 9400, 'images (26).jpg'),
(22, 1265, 1259, 'rabia', '\"\"', '', '', 'Leather Shoes (Orignal)', 'Bahawalpur', 2999, 'Upper Leather', 3, 'Upper Leather,\r\nRubber Sole,\r\nSIze:41 to 45\"', '+923336513516', '2019-06-09 18:10:58', 8997, '031-Shoes-to-wear-with-jeans.jpeg'),
(23, 1266, 1260, 'adeela', '\"\"', '', '', 'dress', 'Bahawalpur', 1880, 'good', 1, 'hfhuewqhgeiq\"', '92333000000', '2019-06-10 08:46:22', 1880, 'images (26).jpg');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `category_name` varchar(50) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_type` enum('seller','admin') NOT NULL DEFAULT 'seller'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category_name`, `image`, `user_id`, `user_type`) VALUES
(2, 'rsfdfgg', NULL, NULL, 'seller'),
(3, 'Lawn', NULL, 1259, 'seller'),
(4, 'Radimate', NULL, 1260, 'seller'),
(5, 'Jeans', NULL, 1259, 'seller'),
(6, 'Radimate', NULL, 1259, 'seller'),
(7, 'shoes', NULL, 1259, 'seller'),
(8, 'court', NULL, 1260, 'seller'),
(9, 'shirts', NULL, 1260, 'seller'),
(10, 'wedding dress', NULL, 1259, 'seller'),
(11, 'suite', NULL, 1259, 'seller'),
(12, 'test', NULL, 1260, 'seller');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(250) DEFAULT NULL,
  `cnic` varchar(250) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `mobile_number` varchar(12) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `password` varchar(11) DEFAULT NULL,
  `image` varchar(345) DEFAULT NULL,
  `type` enum('user','seller','admin') NOT NULL DEFAULT 'user',
  `city` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `customer_name`, `cnic`, `address`, `mobile_number`, `email`, `password`, `image`, `type`, `city`) VALUES
(1253, 'customer', '31202-70111746-4', '189/f', '03009687669', 'customer@customer.com', 'customer', 'candidate_images/Chrysanthemum-jpg.jpg', 'user', NULL),
(1259, 'Admin', '3120269441941', NULL, '9230000000', 'admin@admin.com', 'admin123', '36252369.jpeg', 'admin', 'Bahawalpur'),
(1260, 'Owner', '3120269441941', NULL, '92333000000', 'bowner@bowner.com', 'admin123', '79c2689a332e9946ade72debd15b45eb.jpg', 'seller', 'Bahawalpur'),
(1261, 'User', '3120269441941', NULL, '+920000000', 'user@user.com', 'user123', 'Sample-1---right.jpg', 'user', 'Islamabad'),
(1262, 'rabia', '-1', '189f', '03009687669', 'rabia100789@gmail.com', '123456789', '03-4.jpg', 'user', 'bahawalpur'),
(1263, 'ammar', '1', '3E', '03009687669', 'ammarhameed8726@gmail.com', '123456789', '3b7cb5c291bef9a5162dd7c41cc09267--originals-online-khaadi-lawn-.jpg', 'user', 'Bahawalpur'),
(1264, 'areeba', '1', 'hjhshtj', '1234566777', 'areeba@1234.com', '12345', 'clothingv2._V519740116_.jpg', 'user', 'BAHAWALPUR'),
(1265, 'rabia', '312027011746', '3E', '03057799830', 'rabia1000789@gmail.com', '03057799830', 'Zahra-Ahmed-black-embroidered-Peplum-For-Eid.jpg', 'user', 'BAHAWALPUR'),
(1266, 'adeela', '3120277789625353', 'fdfg', '123456789', 'adeela@1234gmail.com', 'adeela1', 'WhatsApp_Image_2019-01-28_at_9.31_.31_PM_.jpeg', 'user', 'Bahawalpur'),
(1267, 'aqsa', '7582', 'iu9w5', '7542980', 'aqsa@1234', '1234', 'e5a9d14be741793bae39c7c092f44ad9.jpg', 'user', 'Bahawalpur');

-- --------------------------------------------------------

--
-- Table structure for table `order_product`
--

CREATE TABLE `order_product` (
  `id` int(11) NOT NULL,
  `orderid` int(11) DEFAULT NULL,
  `productid` int(50) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `totalprice` int(11) DEFAULT NULL,
  `image` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_product`
--

INSERT INTO `order_product` (`id`, `orderid`, `productid`, `quantity`, `totalprice`, `image`) VALUES
(2, 21111, 34, 35, 36, 'candidate_images/Tulips-jpg.jpg'),
(3, 19, 1321, 3, 120, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `productname` varchar(250) NOT NULL,
  `bo_id` int(11) DEFAULT NULL,
  `description` varchar(250) NOT NULL,
  `Color` varchar(250) NOT NULL,
  `uniteprice` varchar(12) DEFAULT NULL,
  `catagoryid` varchar(150) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `productname`, `bo_id`, `description`, `Color`, `uniteprice`, `catagoryid`, `image`) VALUES
(129, 'product 1', 3, 'JFAL', 'pink', '90', 'hif', 'candidate_images/Lighthouse-jpg.jpg'),
(130, 'twyqr', 2, 'nfnkngk', 'pink', '6584', '122', 'candidate_images/Desert-jpg.jpg'),
(131, 'gughiWH', 123, 'NKNVxlbk', 'MNKVN', '781', '658', 'candidate_images/Tulips-jpg.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `receipt`
--

CREATE TABLE `receipt` (
  `receiptid` int(11) NOT NULL,
  `customerid` int(11) NOT NULL,
  `orderid` varchar(250) DEFAULT NULL,
  `due-date` varchar(250) DEFAULT NULL,
  `issudate` varchar(12) DEFAULT NULL,
  `totalamount` varchar(50) DEFAULT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `receipt`
--

INSERT INTO `receipt` (`receiptid`, `customerid`, `orderid`, `due-date`, `issudate`, `totalamount`, `image`) VALUES
(8, 0, '', '', '', '', 'candidate_images/Chrysanthemum-jpg.jpg'),
(9, 0, 'fd', '', '', '', ''),
(10, 0, 'fd', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(250) DEFAULT NULL,
  `cnic` varchar(250) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `mobile_number` varchar(12) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `password` varchar(11) DEFAULT NULL,
  `image` varchar(345) DEFAULT NULL,
  `type` enum('user','seller','admin') NOT NULL DEFAULT 'user',
  `city` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `customer_name`, `cnic`, `address`, `mobile_number`, `email`, `password`, `image`, `type`, `city`) VALUES
(1253, 'customer', '31202-70111746-4', '189/f', '03009687669', 'customer@customer.com', 'customer', 'candidate_images/Chrysanthemum-jpg.jpg', 'user', NULL),
(1259, 'Admin', '3120269441941', NULL, '9230000000', 'admin@admin.com', 'admin123', '36252369.jpeg', 'admin', 'Bahawalpur'),
(1260, 'Owner', '3120269441941', NULL, '92333000000', 'bowner@bowner.com', 'admin123', '79c2689a332e9946ade72debd15b45eb.jpg', 'seller', 'Bahawalpur'),
(1261, 'User', '3120269441941', NULL, '+920000000', 'user@user.com', 'user123', 'Sample-1---right.jpg', 'user', 'Islamabad'),
(1262, 'rabia', '-1', '189f', '03009687669', 'rabia100789@gmail.com', '123456789', '03-4.jpg', 'user', 'bahawalpur'),
(1263, 'ammar', '1', '3E', '03009687669', 'ammarhameed8726@gmail.com', '123456789', '3b7cb5c291bef9a5162dd7c41cc09267--originals-online-khaadi-lawn-.jpg', 'user', 'Bahawalpur'),
(1264, 'areeba', '1', 'hjhshtj', '1234566777', 'areeba@1234.com', '12345', 'clothingv2._V519740116_.jpg', 'user', 'BAHAWALPUR'),
(1265, 'rabia', '312027011746', '3E', '03057799830', 'rabia1000789@gmail.com', '03057799830', 'Zahra-Ahmed-black-embroidered-Peplum-For-Eid.jpg', 'user', 'BAHAWALPUR'),
(1266, 'adeela', '3120277789625353', 'fdfg', '123456789', 'adeela@1234gmail.com', 'adeela1', 'WhatsApp_Image_2019-01-28_at_9.31_.31_PM_.jpeg', 'user', 'Bahawalpur'),
(1267, 'aqsa', '7582', 'iu9w5', '7542980', 'aqsa@1234', '1234', 'e5a9d14be741793bae39c7c092f44ad9.jpg', 'user', 'Bahawalpur'),
(1268, 'rabia', '-1', '5r736', '03009687669', 'rabia1001789@gmail.com', '123456789', 'da2c1c249fedcf6ca1c480913a7c9516.jpg', 'user', 'Bahawalpur'),
(1269, 'warda', '-1', '567', '526821356815', 'warda@gmail.com', '1234', 'WhatsApp_Image_2018-07-08_at_1.16_.02_PM_.jpeg', 'seller', 'bahawalpur');

-- --------------------------------------------------------

--
-- Table structure for table `register_type`
--

CREATE TABLE `register_type` (
  `register_id` int(11) NOT NULL,
  `customer` varchar(50) DEFAULT NULL,
  `bowner` varchar(11) DEFAULT NULL,
  `admin` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register_type`
--

INSERT INTO `register_type` (`register_id`, `customer`, `bowner`, `admin`) VALUES
(1259, '0', '0', '1'),
(1266, '1', '0', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `boutique_order`
--
ALTER TABLE `boutique_order`
  ADD PRIMARY KEY (`orderid`);

--
-- Indexes for table `boutique_post`
--
ALTER TABLE `boutique_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_product`
--
ALTER TABLE `order_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `receipt`
--
ALTER TABLE `receipt`
  ADD PRIMARY KEY (`receiptid`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register_type`
--
ALTER TABLE `register_type`
  ADD PRIMARY KEY (`register_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `boutique_order`
--
ALTER TABLE `boutique_order`
  MODIFY `orderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `boutique_post`
--
ALTER TABLE `boutique_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1268;

--
-- AUTO_INCREMENT for table `order_product`
--
ALTER TABLE `order_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;

--
-- AUTO_INCREMENT for table `receipt`
--
ALTER TABLE `receipt`
  MODIFY `receiptid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1270;

--
-- AUTO_INCREMENT for table `register_type`
--
ALTER TABLE `register_type`
  MODIFY `register_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1267;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
